import 'package:font_awesome_flutter/font_awesome_flutter.dart';

List categories = [
  {
    "name": "Light car",
    "icon": FontAwesomeIcons.car,
    "items": 2
  },
  {
    "name": "General car",
    "icon": FontAwesomeIcons.car,
    "items": 2
  },
  {
    "name": "Van",
    "icon": FontAwesomeIcons.car,
    "items": 2
  },
  {
    "name": "Construction vehicle",
    "icon": FontAwesomeIcons.car,
    "items": 1
  },
];