// src/main/java/com/example/demo/dto/BoardDeleteRequest.java
package com.example.demo;

public class BoardDeleteRequest {
    private String password;

    // Getter and Setter
    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}


