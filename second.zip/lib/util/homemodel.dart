final List<Map<String, String>> generalmodel = [
  {
    'img': 'assets/img5.png',
    'name': '추천차량과 탄소중립방안을 확인하세요',
    'description': '',
  },
];
final List<Map<String, String>> businessmodel= [
  {
    'img': 'assets/business.png',
    'name': '누적차량의 탄소세를 확인해보세요',
    'description': '',
  },
];